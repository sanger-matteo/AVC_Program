unsigned long FT_Open(
	int deviceNumber,
	unsigned long int *ftHandle
);

unsigned long FT_OpenEx(
	char *pSerNum,
	unsigned long int dwFlags,
	unsigned long int *ftHandle
);

unsigned long FT_Close(
	unsigned long ftHandle
);
 
unsigned long FT_Read(
	unsigned long ftHandle,
	unsigned char *lpBuffer,
	unsigned long nBytesToRead,
	unsigned long *lpBytesReturned
);
   
unsigned long FT_Write(
	unsigned long ftHandle,
	unsigned char *lpBuffer,
	unsigned long nBytesToWrite,
	unsigned long *lpBytesWritten
);
    
unsigned long FT_ResetDevice(
	unsigned long ftHandle
);

unsigned long FT_SetBaudRate(
	unsigned long ftHandle,
	unsigned long BaudRate
);

unsigned long FT_SetDataCharacteristics(
	unsigned long ftHandle,
	unsigned char WordLength,
	unsigned char StopBits,
	unsigned char Parity
);

unsigned long FT_SetFlowControl(
	unsigned long ftHandle,
	unsigned short int FlowControl,
	unsigned char XOn,
	unsigned char XOff
);

unsigned long FT_Purge(
	unsigned long ftHandle,
	unsigned long Flags
);

unsigned long FT_SetDtr(
	unsigned long ftHandle
);

unsigned long FT_SetRts(
	unsigned long ftHandle
);

unsigned long FT_GetDeviceInfo(
    unsigned long ftHandle,
    unsigned long *pftType,
    unsigned long *lpdwID,
    char *pcSerialNumber,
    char *pcDescription,
    char *pvDummy
);
