function [ft_status] = usbio24_setup(handle);
% usbio24_setup
% Sets up the USBIO24 device.
% Sets all bits of a USBIO24 to output.
%
% [ft_status] = usbio24_setup(handle)
%
% handle = Integer handle to the device
% ft_status = Integer status flag
%
% R. Gomez-SJoberg 7/14/05

% Reset
[ft_status] = calllib('FTD2XX', 'FT_ResetDevice', handle);

% Set baud rate to max
[ft_status] = calllib('FTD2XX', 'FT_SetBaudRate', handle, 921600);

% Set WordLength = 8, StopBits = 0, Parity = 0
[ft_status] = calllib('FTD2XX', 'FT_SetDataCharacteristics', handle, 8, 0, 0);

% No flow control
[ft_status] = calllib('FTD2XX', 'FT_SetFlowControl', handle, 0, 0, 0);

% Purge Rx and Tx buffers
[ft_status] = calllib('FTD2XX', 'FT_Purge', handle, 1);
[ft_status] = calllib('FTD2XX', 'FT_Purge', handle, 2);
pause(0.1);

% Set DTR & RTS
[ft_status] = calllib('FTD2XX', 'FT_SetDtr', handle);
[ft_status] = calllib('FTD2XX', 'FT_SetRts', handle);

% Set all bit to output
buffer = uint8(['!A' 0 '!B' 0 '!C' 0]);
num_bytes = 9;
[ft_status, buffer, num_bytes] = calllib('FTD2XX', 'FT_Write', handle, buffer, num_bytes, num_bytes);
