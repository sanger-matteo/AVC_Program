if ~libisloaded('FTD2XX')
    loadlibrary('FTD2XX', 'myFTD2XX');
end;

handle = uint32(0);
phandle = libpointer('int64Ptr', handle);

flags = uint32(1);
status = 0;
device = uint32(0);
ser_num = 'ELCAEP93';

[status, ser_num, handle] = calllib('FTD2XX', 'FT_OpenEx', ser_num, flags, handle)
disp(['Open by serial number. status = ' num2str(status)]);

%[status, handle] = calllib('FTD2XX', 'FT_Open', device, handle)

buffer = uint8('?');
num_bytes = 1;
[status, buffer, num_bytes] = calllib('FTD2XX', 'FT_Write', handle, buffer, 1, num_bytes);
disp(['Request ID. status = ' num2str(status)]);
pause;

buffer = uint8(zeros(100));
[status, buffer, num_bytes] = calllib('FTD2XX', 'FT_Read', handle, buffer, 10, num_bytes);
disp(['Data = ' char(buffer(1:num_bytes)) '. status = ' num2str(status)]);
pause;

buffer = uint8(['!A' 0 '!B' 0 '!C' 0]);
num_bytes = length(buffer);
[status, buffer, num_bytes] = calllib('FTD2XX', 'FT_Write', handle, buffer, num_bytes, num_bytes);
disp(['Set all to output. status = ' num2str(status)]);
pause;

buffer = uint8(['A' 255]);
num_bytes = length(buffer);
[status, buffer, num_bytes] = calllib('FTD2XX', 'FT_Write', handle, buffer, num_bytes, num_bytes);
disp(['Set all to High. status = ' num2str(status)]);
pause;

buffer = uint8(['A' 0]);
num_bytes = length(buffer);
[status, buffer, num_bytes] = calllib('FTD2XX', 'FT_Write', handle, buffer, num_bytes, num_bytes);
disp(['Set all to Low. status = ' num2str(status)]);
pause;

status = calllib('FTD2XX', 'FT_Close', handle)

unloadlibrary('FTD2XX');
